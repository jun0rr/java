/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jun0rr.doxy.tcp;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPromise;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.util.internal.logging.InternalLogger;
import io.netty.util.internal.logging.InternalLoggerFactory;
import java.io.Closeable;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.jun0rr.doxy.cfg.Host;
import net.jun0rr.doxy.common.AddingLastChannelInitializer;
import us.pserver.tools.Unchecked;


/**
 *
 * @author juno
 */
public class TcpClient2 implements Closeable {
  
  private final EventLoopGroup group;
  private volatile ChannelFuture future;
  private final InternalLogger log;
  private final Bootstrap boot;
  private final List<Supplier<TcpHandler>> handlers;
  private final BlockingDeque<TcpEvent> events;
  
  public TcpClient2(Bootstrap bootstrap) {
    this.boot = Objects.requireNonNull(bootstrap, "Bad null Bootstrap");
    this.group = boot.config().group();
    this.log = InternalLoggerFactory.getInstance(getClass());
    this.handlers = new LinkedList<>();
    this.events = new LinkedBlockingDeque<>();
  }
  
  public TcpClient2(EventLoopGroup group) {
    this(bootstrap(group));
  }
  
  public TcpClient2() {
    this(bootstrap(new NioEventLoopGroup(1)));
  }
  
  public static TcpClient2 open() {
    return new TcpClient2();
  }
  
  public static TcpClient2 open(EventLoopGroup group) {
    return new TcpClient2(group);
  }
  
  public static TcpClient2 open(Bootstrap boot) {
    return new TcpClient2(boot);
  }
  
  private static Bootstrap bootstrap(EventLoopGroup group) {
    return new Bootstrap()
        .channel(NioSocketChannel.class)
        .option(ChannelOption.TCP_NODELAY, Boolean.TRUE)
        .option(ChannelOption.AUTO_CLOSE, Boolean.TRUE)
        .option(ChannelOption.AUTO_READ, Boolean.TRUE)
        .group(group);
  }
  
  public List<Supplier<TcpHandler>> handlers() {
    return handlers;
  }
  
  public TcpClient2 addHandler(Supplier<TcpHandler> handler) {
    if(handler != null) handlers.add(handler);
    return this;
  }
  
  private Bootstrap initHandlers(Bootstrap sbt) {
    List<Supplier<ChannelHandler>> ls = new LinkedList<>();
    ls.add(TcpOutboundHandler::new);
    Function<Supplier<TcpHandler>,Supplier<ChannelHandler>> fn = s->()->new TcpInboundHandler(this, s.get());
    handlers.stream().map(fn).forEach(ls::add);
    ls.add(TcpUcaughtExceptionHandler::new);
    return sbt.handler(new AddingLastChannelInitializer(ls));
  }
  
  private void channelConnected() {
    if(future == null) throw new IllegalStateException("Channel not connected");
  }
  
  private void channelNotConnected() {
    if(future != null) throw new IllegalStateException("Channel already connected");
  }
  
  public TcpClient2 connect(Host host) {
    TcpEvent.ConnectEvent evt = b -> {
      System.out.println("--- CONNECT ---");
      ChannelFuture f = initHandlers(b).connect(host.toSocketAddr());
      log.info("TcpClient connected at: {}", host);
      return f;
    };
    events.offerLast(evt);
    return this;
  }
  
  public TcpClient2 send(Object msg) {
    if(msg != null) {
      TcpEvent.FutureEvent evt = f -> {
        System.out.println("--- SEND ---");
        return f.channel().writeAndFlush(msg);
      };
      events.offerLast(evt);
    }
    return this;
  }
  
  public TcpClient2 onComplete(Consumer<Channel> success) {
    return onComplete(success, Unchecked::unchecked);
  }
  
  public TcpClient2 onComplete(Consumer<Channel> success, Consumer<Throwable> error) {
    if(success != null && error != null) {
      TcpEvent.FutureEvent evt = f -> {
        if(f.isSuccess()) success.accept(f.channel());
        else error.accept(f.cause());
        return f;
      };
      events.offerLast(evt);
    }
    return this;
  }
  
  private ChannelFutureListener listener() {
    return new ChannelFutureListener() { 
      @Override 
      public void operationComplete(ChannelFuture f) throws Exception {
        TcpEvent<ChannelFuture> evt = events.pollFirst();
        if(evt != null) {
          future = evt.process(f).addListener(listener());
        }
      }
    };
  }
  
  private TcpClient2 sync() {
    CountDownLatch count = new CountDownLatch(1);
    TcpEvent.FutureEvent evt = f -> {
      System.out.println("--- SYNC ---");
      count.countDown();
      return f;
    };
    events.offerLast(evt);
    future.addListener(listener());
    Unchecked.call(()->count.await());
    return this;
  }
  
  public TcpClient2 start() {
    channelNotConnected();
    TcpEvent<Bootstrap> con = events.pollFirst();
    future = con.process(boot).addListener(listener());
    return this;
  }
  
  public TcpClient2 startSync() {
    start();
    return sync();
  }
  
  @Override
  public void close() {
    channelConnected();
    TcpEvent.FutureEvent e = f->{
      System.out.println("--- CLOSE ---");
      return f.channel().close();
    };
    events.offerLast(e);
    future.addListener(listener());
  }
  
  public void closeSync() {
    close();
    sync();
  }
  
  public void shutdown() {
    close();
    TcpEvent.FutureEvent e = f -> {
      System.out.println("--- SHUTDOWN ---");
      group.shutdownGracefully();
      return f;
    };
    events.offerLast(e);
    future.addListener(listener());
    Unchecked.call(()->group.awaitTermination(10, TimeUnit.SECONDS));
  }
  
}
